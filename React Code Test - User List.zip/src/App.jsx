import React from 'react';
import UserLists from './UserLists';

export function App(props) {
  return (
    <div className='App'>
      <UserLists />
    </div>
  );
}

// Log to console
console.log('Hello console')